<!-- Banner -->
<div>
			<section class="banner full">
				<article>
					<img src="img/slider/slide01.jpg" alt="" />
					<div class="inner">
						<header>
							<p>Sure we have millions of prints in a wide variety of styles.</p>
							<h2>OUR GUARANTEE</h2>
						</header>
					</div>
				</article>
				<article>
					<img src="img/slider/slide02.jpg" alt="" />
					<div class="inner">
						<header>
							<p>we also have over 200 frame styles, plus canvas, wood mount, and art on metal.</p>
							<h2>CUSTOM FINISHED</h2>
						</header>
					</div>
				</article>
				<article>
					<img src="img/slider/slide03.jpg"  alt="" />
					<div class="inner">
						<header>
							<p>If you don’t love it, return it. It’s just that easy.</p>
							<h2>OUR GUARANTEE</h2>
						</header>
					</div>
				</article>
				<article>
					<img src="img/slider/slide04.jpg"  alt="" />
					<div class="inner">
						<header>
							<p>Don’t call it a comeback! We’ve rounded up five ways to make antique art feel new again.</p>
							<h2>Classic Art Modern Way</h2>
						</header>
					</div>
				</article>
				<article>
					<img src="img/slider/slide05.jpg"  alt="" />
					<div class="inner">
						<header>
							<p>Visual search helps you find the perfect piece</p>
							<h2>Find Art with Visual Search</h2>
						</header>
					</div>
				</article>
			</section>
<!-- Visit : www.mayurik.com -->
			</div>